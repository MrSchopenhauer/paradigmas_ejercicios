/**
 * 
 */
/**
 * @author mrschopen
 *
 */
module Carrera {
	requires java.desktop;
}